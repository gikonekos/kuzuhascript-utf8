#! /usr/local/bin/perl

#
#	�����͂�����Ղ� ��24
#	 (���ʊ֐��Q)
#

###############################################################################
#  �����t�H�[�}�b�g�ϊ�
###############################################################################

sub getnowdate {
	
	( $sec, $min, $hour, $mday, $mon, $year, $wday, $yday, $isdat )
		= localtime ( $_[0] );
	$year += 1900;
	$mon++;
	$nowdate = sprintf ( "%d/%02d/%02d(%s)%02d��%02d��%02d�b", 
		$year, $mon, $mday, 
		( '��', '��', '��', '��', '��', '��', '�y' )[$wday],
		$hour, $min, $sec );
}


###############################################################################
#  �t�H�[���f�[�^�擾
###############################################################################

sub getformdata {
	
	local ( $buf, $name, $value );
	
	if ( $ENV{'REQUEST_METHOD'} eq 'POST' ) {
		read ( STDIN, $buf, $ENV{'CONTENT_LENGTH'} );
	} else {
		$buf = $ENV{'QUERY_STRING'};
	}
	
	if ( $buf ne '' ) {
		
		# HTTP_HOST�̃`�F�b�N
		&prterror ( '�Ăяo�������s���ł��B' ) 
		  if ( $ENV{'HTTP_HOST'} ne '' && ! ( $ENV{'HTTP_HOST'} =~ /$bbshost/i ) );
		
		# CGI�Ăяo������URL���擾
		$referer = $ENV{'HTTP_REFERER'};
		$referer =~ s/\+/ /g;
		$referer =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack ( "C", hex ( $1 ) )/eg;
		
		# �t�H�[���̓��e���f�R�[�h
		foreach ( split ( /&/, $buf ) ) {
			( $name, $value ) = split ( /=/ );
			$value =~ s/\+/ /g;
			$value =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack ( "C", hex ( $1 ) )/eg;	
			&jcode'convert ( *value, 'sjis' );
			$value =~ s/</&lt;/g;
			$value =~ s/>/&gt;/g;
			$value =~ s/\r\n/\r/g;
			$value =~ s/\n/\r/g;
			$value =~ s/\r$//;		# ���������s�R�[�h�Ȃ炻����폜
			$value =~ s/\,/\0/g;	# �J���}��null�ɕϊ�
			$FORM{$name} = $value;
		}
	}
}


###############################################################################
#  ������̃G���R�[�h
###############################################################################

sub escstring {
	
	local ( $srcstr ) = $_[0];
	
	$srcstr =~ s/([^a-zA-Z0-9\s])/sprintf ( "%%%lx", ( unpack ( "C", $1 ) ) )/eg;
	$srcstr =~ s/ /\+/g;
	
	return $srcstr;
}

###############################################################################
#  ���b�Z�[�W�ǂݍ���
###############################################################################

sub loadmessage {
	
	open ( READLOG, "$logfilename" ) || &prterror ( '���b�Z�[�W�ǂݍ��݂Ɏ��s���܂���' );
	eval 'flock ( READLOG, 1 )';
	seek ( READLOG, 0, 0 );
	@logdata = <READLOG>;
	eval 'flock ( READLOG, 8 )';
	close ( READLOG );
}


###############################################################################
#  ���b�Z�[�W�P���擾
###############################################################################

sub getmessage {
	
	 ( $ndate, $postid, $protect, $thread, $user, $mail, $link, $title, $msg )
	  = split ( /\,/, $logdata[$i] );
	chop $msg;
	$wdate = &getnowdate ( $ndate );
}


###############################################################################
#  ���b�Z�[�W�P���o��
###############################################################################

sub prtmessage {
	
	local ( $out ) = $_[0];
	local ( $printmode ) = $_[1];
	
	$title =~ s/\0/\,/g;	# null���J���}�ɕϊ�
	$mail =~ s/\0/\,/g;
	$user =~ s/\0/\,/g;
	$link =~ s/\0/\,/g;
	$msg =~ s/\0/\,/g;
	
	$linkdisp = $link;
	if ( $linkdisp =~ /mode=follow\&search=\d*\&ref=.*/ ) {
		$linkdisp =~ s/mode=follow\&search=\d*\&ref=(.*)/�Q�l�F$1/;
		$link =~ s/mode=follow\&(.*)/$cgiurl\?bgcolor=$bgc\&mode=follow\&$1/;
	}
	
	print $out "<font size=\"+1\" color=\"$subjc\"><b>$title</b></font>\n�@���e�ҁF<b>";
	if ( $mail ne '' ) {
		print $out "<a href=\"mailto:$mail\">$user</a>";
	} else {
		print $out "$user";
	}
	print $out "</b></font>\n<font size=\"-1\">�@���e���F$wdate\n";
	
	if ( $printmode == 0 ) {
		print $out "�@<a href=\"$cgiurl\?mode\=follow\&username=",
		  &escstring ( $FORM{'username'} ),
		  "&bgcolor=$bgc\&search\=$postid&autolink=$FORM{'autolink'}\" target=\"link\">��</a>\n",
		  "�@<a href=\"$cgiurl\?mode\=search\&bgcolor\=$bgc\&search\=$user\" target=\"link\">��</a>\n";
		if ( $thread ne '' ) {
			print $out "�@<a href=\"$cgiurl\?bgcolor\=$bgc\&mode\=thread\&search\=$thread\" target=\"link\">��</a>\n";
		}
	}
	print $out "</font><p>\n<blockquote><pre>$msg</pre></p>\n";
	
	if ( $link ne '' ) {
		if ( ( $printmode == 1 && $link eq $linkdisp ) ||
		  ( $printmode == 0 && 
		  ( $linkusage == 1 || ( $linkusage == 0 && $link =~ /$urltop/i ) ) ) ) {
			print $out "<a href=\"$link\" target=\"link\">$linkdisp</a>\n";
		} else {
			print $out "<font color=\"#$linkc\"><u>$linkdisp</u></font>\n";
		}
	}
	print $out "</blockquote></p>\n\n<hr>\n"
}


###############################################################################
#  �t�b�^�����\��
###############################################################################

sub prtfooter {
	
	print <<"__EOF__";
<hr size=5><p align=\"right\"><font size=\"-1\">
<a href="http://www4.famille.ne.jp/~kuzuha/script.html">�����͂�����Ղ�</A> ��24</font></body></html>
__EOF__
}


###############################################################################
#  �����ɂ����J�E���^�[����
###############################################################################

sub counter {
	
	local ( @count, @filenumber, @sortedcount, $maxcount, $mincount );
	
	for ( $i = 0 ; $i < $countlevel ; $i++ ) {
		open ( IN, "$countfile$i.dat" );
		$count[$i] = <IN>;
		$filenumber{$count[$i]} = $i;
		close ( IN );
	}
	
	@sortedcount = sort { $a <=> $b; } @count;
	$maxcount = $sortedcount[$countlevel-1];
	$mincount = $sortedcount[0];
	
	$maxcount++;
	print $maxcount;
	
	open ( OUT, ">$countfile$filenumber{$mincount}.dat" );
	print OUT $maxcount;
	close ( OUT );
}


###############################################################################
#  �G���[���b�Z�[�W�\��
###############################################################################

sub prterror {
	
	local ( $error ) = $_[0];
	
	if ( $error eq 'xx' ) {
		$errmsg = '���킢����';
	} else {
		$errmsg = $error;
	}
	
	print "Content-type: text/html\n\n",
	  "<html><head><title>$bbstitle (error)</title></head>\n",
	  "$body\n<h3>$errmsg</h3>\n";
	
	if ( $error eq 'xx' ) {
		for ( $i = 0 ; $i < 10 ; $i++ ) {
			print '<table><tr><td><table><tr><td><table><tr><td><table><tr><td><table><tr><td><table><tr><td><table><tr><td><table><tr><td><table><tr><td><table><tr><td>\n';
		}
		for ( $i = 0 ; $i < 10 ; $i++ ) {
			print '</td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table></td></tr></table>\n';
		}
	}
	
	print "</body></html>\n";
	exit;
}

1;


__END__
