#! /usr/local/bin/perl

#
#	�����͂�����Ղ� Final Beta #2 pl0.3
#	 (�o�^�p�֐��Q)
#

###############################################################################
#  ���b�Z�[�W�`�F�b�N
###############################################################################

sub chkmessage {
	
	if ( ! ( $referer =~ /$cgiurl/i ) ) {
		&chkerror ( "���e��ʂ̂t�q�k��<br>$cgiurl<br>" .
		  '�ȊO����̓��e�͂ł��܂���B',  3 );
	}
	
	$i = 0;
	foreach ( split ( /\r/, $FORM{'message'} ) ) {
		if ( length ( $_ ) > $maxmsgcol ) {
			$i++;
		}
	}
	if ( $i != 0 ) { &chkerror ( '���e���e�̌������傫�����܂��B', 10 ); }
	
	if ( ( $FORM{'message'} =~ tr/\r/\r/ ) > ( $maxmsgline - 1 ) ) {
		&chkerror ( '���e���e�̍s�����傫�����܂��B', 11 );
	}
	
	if ( length ( $FORM{'message'} ) > $maxmsgsize ) {
		&chkerror ( '���e���e���傫�����܂��B', 12 );
	}
	
	if ( $FORM{'protect'} ne '' ) {
		my @hostbin = split ( /\./, $ENV{'REMOTE_ADDR'} );
		for ( $i = 0 ; $i < 4 ; $i++ ) {
			$hostbin[$i] = vec ( pack ( 'C4', $hostbin[$i] ), 0, 8 );
		}
		$protect_c = $hostbin[0] ^ $hostbin[1] ^ $hostbin[2] ^ $hostbin[3];
		$pcheck = ( $FORM{'protect'} - $protect_c ) / $protect_b - $protect_a;
		&getnowdate ( $pcheck );
		if ( ( $sec  < 0 ) || ( $sec  > 60 ) || 
		  ( $min  < 0 ) || ( $min  > 60 ) ||
		  ( $hour < 0 ) || ( $hour > 24 ) ) {
			&chkerror ( '', 32 );
		}
		if ( ( $nowtime - $pcheck ) < $pstime ) {
			&chkerror ( '������x��蒼���ĉ������B', 30 );
		}
		if ( ( $nowtime - $pcheck ) > $pltime ) {
			&chkerror ( '', 31 );
			if ( $FORM{'follow'} ne '' ) {
				&prtfollow ( 1 );
			} else {
				&prtboard ( $FORM{'title'}, $FORM{'message'}, $FORM{'linkurl'} );
			}
			exit;
		}
	} else {
		&chkerror ( '�t�H�[���f�[�^�̈ꕔ�Ɍ���������܂��B������x��蒼���ĉ������B', 33 );
	}
	
	if ( $FORM{'mailaddr'} =~ / /i ) {
		$FORM{'mailaddr'} = '';
	}
	if ( $FORM{'mailaddr'} ne '' ) {
		if ( ! ( $FORM{'mailaddr'} =~ /(.*)\@(.*)\.(.*)/ ) ) {
			&chkerror ( '���[���A�h���X�����������͂���Ă��܂���B', 20 );
		} elsif ( $FORM{'mailaddr'} =~ /,/ ) {
			&chkerror ( '���[���A�h���X�͕����w��ł��܂���B', 21 );
		}
	}
	
	if ( $FORM{'title'} eq '' ) {
		$FORM{'title'} = ' ';
	}
	
	if ( $FORM{'username'} eq '' ) {
		$FORM{'username'} = '�@';
	}
	
	if ( crypt ( "[$FORM{'username'}]", 'r7' ) eq $adminpost ) {
		$FORM{'username'} = $adminname;
		$FORM{'mailaddr'} = $adminmail;
	} else {
		if ( $FORM{'username'} eq $adminpost ) {
			$FORM{'username'} = "$adminname�i�n�J�[�j";
		}
		if ( $FORM{'username'} =~ /$adminname/i ) {
			my $admincheck = $FORM{'username'};
			$admincheck =~ s/ //g;
			$admincheck =~ s/�@//g;
			$admincheck =~ s/_//g;
			if ( $admincheck eq $adminname ) {
				$FORM{'username'} =~ s/$adminname/$adminname�i�x��j/;
			}
		}
	}
	
	if ( $autolink eq '1' ) {
		$FORM{'message'} =~ s#((https?|ftp|gopher|telnet|whois|news)://(=[\x21-\xfc]+|[\x21-\x7e])+)#<a href="$1" target="link">$1</a>#ig;
	}
	
	if ( $FORM{'linkurl'} =~ '^\w+\:\/\/$' || $FORM{'linkurl'} =~ /\s+/ || $FORM{'linkurl'} eq '' ) {
		$FORM{'linkurl'} = '';
	} else {
		$FORM{'linkurl'} =~ s/http:\/\/http:\/\//http:\/\//;
		$FORM{'message'} .= "\r\r<a href=\"$FORM{'linkurl'}\" target=\"link\">$FORM{'linkurl'}</a>";
	}
	if ( $FORM{'follow'} ne '' ) {
		( $i, $j ) = split ( /:/, $FORM{'follow'} );
		$FORM{'message'} .= "\r\r<a href=\"mode=follow\&search=$i\&ref=$j\">�Q�l�F$j</a>";
	}
}


###############################################################################
#  ���b�Z�[�W�`�F�b�N�G���[����
###############################################################################

sub chkerror {
	
	my $errstr = $_[0];
	$posterr = $_[1];
	
	&prterror ( $errstr ) if ( $errstr ne '' );
}


###############################################################################
#  ���b�Z�[�W�o�^
###############################################################################

sub putmessage {
	
	open ( FLOG, "+<$logfilename" ) || &prterror ( '���b�Z�[�W�ǂݍ��݂Ɏ��s���܂���' );
	eval 'flock ( FLOG, 2 )';
	seek ( FLOG, 0, 0 );
	@logdata = <FLOG>;
	
	$i = 0;
	$posterr = 0;
	while ( $i < $logsave && $posterr == 0 ) {
		@items = split ( /\,/, $logdata[$i] );
		$items[9] =~ s/\n$//;
		$posterr = 1 if ( $i < $checkcount && $FORM{'message'} eq $items[9] );
		$posterr = 2 if ( $FORM{'protect'} eq $items[2] );
		$i++;
	}
	
	if ( $posterr == 0 ) {
		
		@items = split ( /\,/, $logdata[0] );
		$newpostid = $items[1] + 1;
		$msgdata = "$nowtime,$newpostid,$FORM{'protect'},$FORM{'thread'},$host,$agent,$FORM{'username'},$FORM{'mailaddr'},$FORM{'title'},$FORM{'message'}\n";
		
		@logdata = @logdata[0 .. $logsave - 2] if ( @logdata >= $logsave );
		unshift ( @logdata, $msgdata );
		
		$oldstream = select ( FLOG );
		$| = 1;
		seek ( FLOG, 0, 0 );
		truncate ( FLOG, 0 );
		print FLOG @logdata;
		eval 'flock ( FLOG, 8 )';
		close ( FLOG );
		
		select ( $oldstream );
		
		$wdate = &getnowdate ( $nowtime );
		&prtoldlog;
		
	} else {
		eval 'flock ( FLOG, 8 )';
		close ( FLOG );
		
		if ( $posterr == 2 ) {
			&chkerror ( '', $posterr );
			if ( $FORM{'follow'} ne '' ) {
				&prtfollow ( 1 );
			} else {
				&prtboard ( $FORM{'title'}, $FORM{'message'}, $FORM{'linkurl'} );
			}
			exit;
		}
	}
}


###############################################################################
#  �ߋ����O�o��
###############################################################################

sub prtoldlog {
	
	if ( $oldlogfiledir ne '' ) {
		
		$user = $FORM{'username'};
		$mail = $FORM{'mailaddr'};
		$link = $FORM{'linkurl'};
		$title = $FORM{'title'};
		$msg = $FORM{'message'};
		
		if ( $oldlogsavesw == 0 ) {
			$oldlogfilename = sprintf ( "%s/%d%02d%02d.html",
				$oldlogfiledir, $year, $mon, $mday );
		} else {
			$oldlogfilename = sprintf ( "%s%d%02d.html",
				$oldlogfiledir, $year, $mon );
		}
		
		open ( CLOG, ">>$oldlogfilename" ) || &prterror ( '�ߋ����O�o�͂Ɏ��s���܂���' );
		eval 'flock ( CLOG, 2 )';
		
		$oldstream = select ( CLOG );
		$| = 1;
		
		if ( -z CLOG ) {
			print CLOG "<html>\n<head><title>$pagetitle</title>\n</head>\n",
			  "<body bgcolor=\"#$oldlogbgc\" text=\"#$textc\" link=\"#$linkc\"",
			  " vlink=\"#$vlinkc\" alink=\"#$alinkc\">\n<hr>";
		}
		
		&prtmessage ( 'CLOG', 1 );
		
		eval 'flock ( CLOG, 8 )';
		close ( CLOG );
		
		select ( $oldstream );
		
		chmod 0400, $logfilename if ( ( -s $oldlogfilename ) > $maxoldlogsize );
		
		&getnowdate ( time + $difftime - $oldlogsaveday * 60 * 60 * 24 );
		$oldlogfilename = sprintf (  "%s/%d%02d%02d.html",
			$oldlogfiledir, $year, $mon, $mday );
		unlink $oldlogfilename;
	}
}

1;


__END__
